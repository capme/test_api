<?php
$ch = curl_init();

//$url = "https://fulfillment.api.acommercedev.com/channel/frisianflag/sales-order-status?since=2015-06-18T10:30:40Z&orderStatus=NEW";
/*
return : empty json
*/
$url = "https://fulfillment.api.acommercedev.com/channel/frisianflag/sales-order-status/id?id=201602016188109";
/*
return :
[{"orderId":"FRIS00001","error":{"code":404,"message":"Not Found"}}]
*/
//$url = "https://fulfillment.api.acommercedev.com/channel/frisianflag/sales-order-status";
/*
return : empty json
*/

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");  
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
	'X-Subject-Token: 4abaca82faba4fe186d0092b35309780',
	'User-Agent: Mozilla Firefox'
	)
);                                                                                                                   
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); 
curl_setopt($ch, CURLOPT_VERBOSE, 1);
$result = curl_exec($ch);
//echo $result;
print_r(json_decode($result, true));


?>